﻿Dreikanterbot 3.0.0 desktop client

1. Double-click Dreikanterbot.exe.
2. Enter your deployed server URL on first launch (for example https://chat.example.com).
3. Sign in and use chat, memory and plugins.

The desktop shell only renders the web workspace; model keys and conversations stay on your server.
Use File -> Change server address if the URL is wrong.
Requires Microsoft Edge WebView2 Runtime (usually included with Windows 10/11).
